
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Bhagavad Gita API endpoint template for Chapter and Verse
BHAGAVAD_GITA_API_ENDPOINT = "https://bhagavadgitaapi.in/slok/{chapter}/{verse}/"
TRANSLATION_API_ENDPOINT = "https://api.mymemory.translated.net/get?q={text}&langpair=sa|hi"

# Function to fetch Bhagavad Gita verse for a given chapter and verse
def fetch_bhagavad_gita_verse(chapter, verse):
    try:
        api_endpoint = BHAGAVAD_GITA_API_ENDPOINT.format(chapter=chapter, verse=verse)
        response = requests.get(api_endpoint)

        if response.status_code == 200:
            data = response.json()
            sanskrit_text = data.get("slok")

            # Translate Sanskrit to Hindi using mymemory API
            translation_response = requests.get(TRANSLATION_API_ENDPOINT.format(text=sanskrit_text))
            translation_data = translation_response.json()
            hindi_translation = translation_data.get("responseData", {}).get("translatedText", "")

            return sanskrit_text, hindi_translation
        else:
            return "Unable to retrieve Bhagavad Gita information."
    except Exception as e:
        print("Error:", e)
        return "An error occurred while fetching Bhagavad Gita data."

# Function to fetch Bhagavad Gita chapter details
def fetch_bhagavad_gita_chapter(chapter):
    try:
        api_endpoint = f"https://bhagavadgitaapi.in/chapter/{chapter}/"
        response = requests.get(api_endpoint)

        if response.status_code == 200:
            data = response.json()
            return data
        else:
            return "Unable to retrieve Bhagavad Gita chapter information."
    except Exception as e:
        print("Error:", e)
        return "An error occurred while fetching Bhagavad Gita chapter data."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input'].strip().lower()

    if user_input == 'exit':
        return jsonify({"response": "Thank you for the conversation. Goodbye!"})
    
    if user_input in ['hi.', 'hello.', 'namaste.', 'हैलो।', 'हाइ।', 'नमस्ते।', 'ही।']:
        return jsonify({"response": "radhe radhe! my name is Krishna. How can I help you?"})
    
    if user_input.startswith('verse'):
        try:
            _, chapter, verse = user_input.split()
            chapter = int(chapter)
            verse = int(verse)

            sanskrit_text, hindi_translation = fetch_bhagavad_gita_verse(chapter, verse)
            response = f"Chapter {chapter}, Verse {verse}:\nSanskrit: {sanskrit_text}\nHindi: {hindi_translation}"

            return jsonify({"response": response})

        except ValueError:
            return jsonify({"response": "Invalid input. Please use 'verse x y' format."})
    if user_input in ['What is your name?']:
        return jsonify({"response": "Hello my name is Krishna. How can I help you?"})
    elif user_input.startswith('chapter'):
        try:
            _, chapter_number = user_input.split()
            chapter_number = int(chapter_number)

            chapter_data = fetch_bhagavad_gita_chapter(chapter_number)
            chapter_name = chapter_data.get("name", "Unknown Chapter")
            verses_count = chapter_data.get("verses_count", 0)

            response = f"{chapter_name} ({verses_count} verses)\n"

            for verse_number in range(1, verses_count + 1):
                sanskrit_text, hindi_translation = fetch_bhagavad_gita_verse(chapter_number, verse_number)
                response += f"Verse {verse_number}:\nSanskrit: {sanskrit_text}\nHindi: {hindi_translation}\n"

            return jsonify({"response": response})

        except ValueError:
            return jsonify({"response": "Invalid input. Please use 'chapter x' format to fetch a chapter."})

    else:
        return jsonify({"response": "Translation for web scraping data is not implemented in this example."})

if __name__ == '__main__':
    app.run(debug=True)

